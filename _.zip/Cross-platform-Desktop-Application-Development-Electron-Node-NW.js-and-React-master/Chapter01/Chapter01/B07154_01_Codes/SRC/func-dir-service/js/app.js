const { TitleBarActionsView } = require( "./js/View/TitleBarActions" );

new TitleBarActionsView( document.querySelector( "[data-bind=titlebar]" ) );
