
function double( x ){
  return x * 2;
}

exports.double = double;